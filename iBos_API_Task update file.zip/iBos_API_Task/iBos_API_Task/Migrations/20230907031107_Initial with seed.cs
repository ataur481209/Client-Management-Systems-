﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace iBos_API_Task.Migrations
{
    public partial class Initialwithseed : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
