﻿namespace iBos_API_Task.Model.ViewModel
{
    public class UserModels
    {
        public string LoginID { get; set; } = default!;
        public string Password { get; set; } = default!;
        public string UserMessage { get; set; } = default!;
        public string UserToken { get; set; } = default!;
    }
}
